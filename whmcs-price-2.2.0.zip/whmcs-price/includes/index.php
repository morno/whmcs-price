<?php
// Silence is golden.
// This file is intentionally left blank.
// It exists to prevent directory browsing.
